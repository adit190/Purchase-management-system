﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PurchaseManagementSystem.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PurchaseManagementSystem.WebApi.Repositories;
namespace PurchaseManagementSystem.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PurchaseController : ControllerBase
    {
        private readonly IPurchaseRepository _purchaseRepository;

        public PurchaseController(IPurchaseRepository purchaseRepository)
        {
            _purchaseRepository = purchaseRepository;
        }
        [HttpPost("")]
        public async Task<IActionResult> AddPurchaseDetails([FromBody] PurchaseTable purchaseTable)
        {
            await _purchaseRepository.AddPurchaseDetailsAsync(purchaseTable);

            return Ok("Added Succesfully");
        }
        [HttpPut]
        public async Task<bool> UpdatePurchaseDetails([FromBody] PurchaseTable purchaseTable, string purchaseId)
        {
            var comfirmattion = await _purchaseRepository.UpdatePurchaseDetailsAsync(purchaseId, purchaseTable);
            return comfirmattion;
        } 
        [HttpDelete]
        public async Task<bool> DeletePurchaseDetails([FromBody] string purchaseId)
        {
            var confirmation = await _purchaseRepository.DeleteBookAsync(purchaseId);
            return confirmation;
        }
        [HttpGet("")]
        public async Task<IEnumerable<PurchaseTable>> GetAllPurchaseDetails()
        {
            var details = await _purchaseRepository.GetAllPurchaseDetailsAsync();
            return details;
        }
        [HttpGet("{supplierId}")]
        public async Task<PurchaseTable> GetAllPurchaseDetailsByID([FromRoute]string supplierId)
        {
            var details = await _purchaseRepository.GetPurchaseDetailsByIDAsync(supplierId);
            return details;
        }
    }
}
