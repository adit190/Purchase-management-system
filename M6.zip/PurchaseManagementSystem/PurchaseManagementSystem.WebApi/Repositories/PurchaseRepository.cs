﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PurchaseManagementSystem.WebApi.Models;

namespace PurchaseManagementSystem.WebApi.Repositories
{
    public class PurchaseRepository : IPurchaseRepository
    {
        private readonly PurchaseDBContext _context;

        public PurchaseRepository(PurchaseDBContext context)
        {
            _context = context;
        }


        public async Task AddPurchaseDetailsAsync(PurchaseTable purchase)
        {
            var purchas = new PurchaseTable()
            {
                PurchaseId = purchase.PurchaseId,
                SupplierId = purchase.SupplierId,
                Date = purchase.Date,
                GrandTotal = purchase.GrandTotal,
                AddedOn = purchase.AddedOn,
                AddedBy = purchase.AddedBy,
                LastUpdated = purchase.LastUpdated,
                PurchaseDate  =purchase.PurchaseDate,
                Vendorcode = purchase.Vendorcode,
                Description = purchase.Description,
                IsPoClosed = purchase.IsPoClosed
            };

            _context.PurchaseTables.Add(purchas);      
            await _context.SaveChangesAsync();
        }

        public async Task<bool> UpdatePurchaseDetailsAsync(string purchaseId, PurchaseTable purchase)
        {
            var Purchase = new PurchaseTable()
            {
                PurchaseId = purchase.PurchaseId,
                SupplierId = purchase.SupplierId,
                Date = purchase.Date,
                GrandTotal = purchase.GrandTotal,
                AddedOn = purchase.AddedOn,
                AddedBy = purchase.AddedBy,
                LastUpdated = purchase.LastUpdated,
                PurchaseDate = purchase.PurchaseDate,
                Vendorcode = purchase.Vendorcode,
                Description = purchase.Description,
                IsPoClosed = purchase.IsPoClosed,
            };

            _context.PurchaseTables.Update(Purchase);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteBookAsync(string purchaseId)
        {
            var Purchase = new PurchaseTable()
            {
                PurchaseId = purchaseId
            };

            _context.PurchaseTables.Remove(Purchase);
            await _context.SaveChangesAsync();
            return true;
        }
        public async Task<IEnumerable<PurchaseTable>> GetAllPurchaseDetailsAsync()
        {
            var records = await _context.PurchaseTables.ToListAsync();
            return records;
        }
        public async Task<PurchaseTable> GetPurchaseDetailsByIDAsync(string supplierId)
        {
            var details = await _context.PurchaseTables.FindAsync(supplierId);
            return details;
        }
    }
}
