﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PurchaseManagementSystem.WebApi.Models
{
    public partial class PurchaseTable
    {
        public string PurchaseId { get; set; }
        public string SupplierId { get; set; }
        public DateTime? Date { get; set; }
        public decimal? GrandTotal { get; set; }
        public string AddedOn { get; set; }
        public string AddedBy { get; set; }
        public string LastUpdated { get; set; }
        public DateTime PurchaseDate { get; set; }
        public string Vendorcode { get; set; }
        public string Description { get; set; }
        public bool? IsPoClosed { get; set; }

        public virtual SupplierTable Supplier { get; set; }
    }
}
